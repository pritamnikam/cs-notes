# Evaluation guide: metrics and rubrics

## 1. Build an eval set
30-100 real queries is a useful minimum. Mix three query types, because each retriever wins on a different one:

| Type | Example | Expected winner |
|------|---------|-----------------|
| Exact / identifier | `ts_rank_cd`, error codes, product names | keyword |
| Paraphrase / conceptual | "merge ranked lists without normalizing" | semantic |
| Mixed / multi-concept | "pgvector index recall vs latency" | hybrid |

Label **document-level** graded relevance per query (JSON accepted by the UI and `POST /eval/run`):
`{"query": "...", "relevant": {"doc_title": 3, "other_doc": 1}}`.

## 2. Relevance rubric (graded judgments)

| Grade | Meaning | Test |
|-------|---------|------|
| 3 | Directly answers | A reader could answer the query from this passage alone |
| 2 | Partially answers | Contains part of the answer or the key fact, needs another source |
| 1 | Related | Right topic, doesn't answer |
| 0 | Irrelevant | Wrong topic or only keyword coincidence |

Two reviewers on ~20% of queries; target Cohen's kappa ≥ 0.6, resolve disagreements before using the set.

## 3. Metrics (all computed by the Evaluate tab)

| Metric | Answers | Use for |
|--------|---------|---------|
| **nDCG@k** | Are the best docs ranked highest (graded)? | Primary headline metric for all three modes |
| **Recall@k** | Did we retrieve the relevant docs at all? | Candidate stage; also compute at k=50 *before* reranking to size the rerank pool |
| **MRR** | How soon is the first good result? | Question-answering / "single best" use cases |
| **MAP@k** | Quality across all relevant docs | Several relevant docs per query |
| **Precision@k** | How much of the top-k is useful? | Context-window budgeting for RAG |
| **Hit@k** | Any relevant doc in top-k? | Coarse health check |
| **Keyword/semantic overlap (Jaccard)** | Do the retrievers find different things? | Low overlap = hybrid has room to help; high = redundant |
| **Latency p50 / p95** | Per-stage cost | Budgeting (timings are in every response) |
| **Search confidence calibration** | Does higher confidence mean more often correct? | Bucket confidence (0-.2, .2-.4 ...) vs mean nDCG/hit rate; should be monotonic |

Optional additions: **LLM-as-judge** relevance (cheap proxy for human grades; spot-check against humans),
**groundedness / citation precision** for generated answers, **diversity** (distinct docs in top-k),
**unanswerable-query rejection rate** (do low-confidence searches correctly abstain?).

## 4. System scorecard (suggested acceptance criteria: tune to your use case)

| Dimension | Pass criterion |
|-----------|----------------|
| Hybrid vs best single retriever | nDCG@k ≥ best single mode (no regression), clearly better on mixed queries |
| Reranker value | nDCG@k gain ≥ 0.03 over hybrid for the added latency; otherwise disable |
| Candidate recall | Recall@50 (pre-rerank) ≥ 0.95 |
| Exact-term queries | Keyword or hybrid MRR ≥ 0.9 |
| Paraphrase queries | Semantic or hybrid nDCG@k not below keyword |
| Confidence | Monotonic across buckets; top bucket hit rate ≥ 0.9 |
| Citations | ≥ 95% of cited spans actually support the claim (human spot check) |
| Latency | p95 total within your budget (e.g. < 300 ms retrieval-only, < 1.5 s with cross-encoder) |
| Robustness | Typos, synonyms, very short and very long queries each within 10% of baseline nDCG |
| Freshness | Re-ingest of a changed file replaces old chunks; unchanged files are skipped |

## 5. Choosing a score cutoff
Use the Evaluate tab's threshold explorer (or the numbers below) on your labelled set:
1. Choose the score to cut on (rerank score preferred) and what counts as relevant (grade ≥ 1, 2 or 3).
2. Set a target recall (for discovery tasks, 0.9 is a sensible start) and read off the suggested cutoff and its precision.
3. Check the *retrieval ceiling* first: if it is below your target, no cutoff helps. Fix retrieval (candidates, summaries, embedding model).
4. Inspect the "relevant documents lost" and "irrelevant documents returned" lists to see *why* the cutoff misbehaves.
5. Apply it with `min_score` / `min_score_signal` and re-check after any model, chunking or reranker change, because scores shift.

## 6. Tuning loop
1. Run the eval set for keyword / semantic / hybrid; read the per-query table for failures.
2. Tune in this order: chunk size/overlap → embedding model → fusion (RRF vs weighted α) → candidate counts → reranker.
3. Re-run after every change; keep the summary tables (`eval_runs` stores each summary).
4. Fit confidence constants (`SEM_FLOOR`, `SEM_CEILING`, `KW_CEILING`) so confidence buckets track hit rate.
