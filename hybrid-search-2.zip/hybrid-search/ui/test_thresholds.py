import math

import thresholds as th


def _pq():
    return [
        {"query": "q1", "relevant": {"A": 3, "B": 1}, "modes": {"hybrid": {"scored": [
            {"doc": "A", "grade": 3, "signals": {"final": 0.9}},
            {"doc": "X", "grade": 0, "signals": {"final": 0.6}},
            {"doc": "B", "grade": 1, "signals": {"final": 0.4}},
            {"doc": "Y", "grade": 0, "signals": {"final": 0.2}}]}}},
        {"query": "q2", "relevant": {"C": 3, "D": 3}, "modes": {"hybrid": {"scored": [
            {"doc": "C", "grade": 3, "signals": {"final": 0.8}},
            {"doc": "Z", "grade": 0, "signals": {"final": 0.5}},
            {"doc": "W", "grade": 0, "signals": {"final": None}}]}}},  # missing signal -> dropped
    ]


def test_collect_and_grade_threshold():
    rows, total = th.collect_rows(_pq(), "hybrid", "final", min_grade=1)
    assert total == 4 and len(rows) == 6          # W dropped
    rows3, total3 = th.collect_rows(_pq(), "hybrid", "final", min_grade=3)
    assert total3 == 3 and sum(r["relevant"] for r in rows3) == 2   # B (grade 1) no longer relevant


def test_metrics_at_cutoff():
    rows, total = th.collect_rows(_pq(), "hybrid", "final", 1)
    m = th.metrics_at(rows, total, 0.5)           # keeps A, X, C, Z
    assert m["returned"] == 4 and m["true_positives"] == 2
    assert math.isclose(m["precision"], 0.5) and math.isclose(m["recall"], 0.5)   # D never retrieved
    assert th.metrics_at(rows, total, 0.99)["precision"] is None


def test_cutoff_for_recall_and_ceiling():
    rows, total = th.collect_rows(_pq(), "hybrid", "final", 1)
    c, m = th.cutoff_for_recall(rows, total, 0.75)   # need A, B, C
    assert math.isclose(c, 0.4) and math.isclose(m["recall"], 0.75)
    assert th.cutoff_for_recall(rows, total, 1.0) is None   # D was never retrieved: ceiling is 0.75


def test_sweep_and_histogram():
    rows, total = th.collect_rows(_pq(), "hybrid", "final", 1)
    s = th.sweep(rows, total, steps=10)
    assert len(s) == 10 and s[0]["recall"] >= s[-1]["recall"]       # recall never rises with the cutoff
    h = th.histogram(rows, bins=4)
    assert sum(b["relevant"] + b["irrelevant"] for b in h) == len(rows)
