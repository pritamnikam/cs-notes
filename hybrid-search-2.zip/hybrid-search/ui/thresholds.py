"""Pure helpers for the score-threshold explorer (no Streamlit / network imports, easy to unit test).

A "row" is one retrieved document for one query: {"query", "doc", "value", "relevant"}.
Documents that lack the chosen score (e.g. no keyword match) are left out of `rows`, which is the
same as being below every cutoff. Relevant documents that were never retrieved still count in
`total_relevant`, so recall can never exceed what retrieval actually found (the "ceiling").
"""
import numpy as np


def collect_rows(per_query: list[dict], mode: str, signal: str, min_grade: int) -> tuple[list[dict], int]:
    rows, total_relevant = [], 0
    for pq in per_query:
        total_relevant += sum(1 for g in pq["relevant"].values() if g >= min_grade)
        for d in pq["modes"][mode]["scored"]:
            v = d["signals"].get(signal)
            if v is None:
                continue
            rows.append({"query": pq["query"], "doc": d["doc"], "value": float(v), "relevant": d["grade"] >= min_grade})
    return rows, total_relevant


def metrics_at(rows: list[dict], total_relevant: int, cutoff: float) -> dict:
    """Micro-averaged precision / recall / F1 over all queries if we keep only value >= cutoff."""
    kept = [r for r in rows if r["value"] >= cutoff]
    tp = sum(1 for r in kept if r["relevant"])
    precision = tp / len(kept) if kept else None
    recall = tp / total_relevant if total_relevant else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if precision and (precision + recall) else 0.0
    return {"returned": len(kept), "true_positives": tp, "precision": precision, "recall": recall, "f1": f1}


def sweep(rows: list[dict], total_relevant: int, steps: int = 60) -> list[dict]:
    if not rows:
        return []
    values = [r["value"] for r in rows]
    return [{"cutoff": float(c), **metrics_at(rows, total_relevant, float(c))}
            for c in np.linspace(min(values), max(values), steps)]


def cutoff_for_recall(rows: list[dict], total_relevant: int, target: float):
    """Highest cutoff that still reaches `target` recall, with its metrics; None if unreachable."""
    for c in sorted({r["value"] for r in rows}, reverse=True):
        m = metrics_at(rows, total_relevant, c)
        if m["recall"] >= target:
            return c, m
    return None


def histogram(rows: list[dict], bins: int = 12) -> list[dict]:
    """Counts of relevant vs irrelevant documents per score bin."""
    values = np.array([r["value"] for r in rows])
    lo, hi = float(values.min()), float(values.max())
    if hi - lo < 1e-12:
        hi = lo + 1e-6
    edges = np.linspace(lo, hi, bins + 1)
    rel, _ = np.histogram([r["value"] for r in rows if r["relevant"]], edges)
    irr, _ = np.histogram([r["value"] for r in rows if not r["relevant"]], edges)
    return [{"bin": round(float((edges[i] + edges[i + 1]) / 2), 4), "relevant": int(rel[i]), "irrelevant": int(irr[i])}
            for i in range(bins)]
