import json
import os
import time

import pandas as pd
import requests
import streamlit as st

import thresholds as th

API = os.getenv("API_URL", "http://localhost:8000")
st.set_page_config(page_title="Hybrid Search Lab", page_icon="🔎", layout="wide")

SAMPLE_EVAL = {
    "queries": [
        {"query": "ts_rank_cd cover density ranking", "relevant": {"postgres_full_text_search": 3}},
        {"query": "how do I merge ranked lists from several retrievers without normalizing scores",
         "relevant": {"reciprocal_rank_fusion": 3}},
        {"query": "approximate nearest neighbour index for vectors", "relevant": {"pgvector_indexes": 3}},
        {"query": "rescoring the query and passage together for better accuracy",
         "relevant": {"cross_encoder_reranking": 3}},
        {"query": "run an embedding model locally", "relevant": {"ollama_embeddings": 3}},
        {"query": "avoid request timeouts on long jobs", "relevant": {"fastapi_background_tasks": 3}},
        {"query": "how big should chunks be and should they overlap",
         "relevant": {"chunking_strategies": 3, "ollama_embeddings": 1}},
    ]
}


# ------------------------------------------------------------------ helpers
def call(method: str, path: str, **kw):
    try:
        r = requests.request(method, f"{API}{path}", timeout=kw.pop("timeout", 900), **kw)
    except requests.RequestException as e:
        st.error(f"Cannot reach the API at {API}: {e}")
        st.stop()
    if not r.ok:
        st.error(f"API error {r.status_code}: {r.text[:600]}")
        st.stop()
    return r.json()


@st.cache_data(ttl=20)
def get_models() -> dict:
    try:
        return requests.get(f"{API}/models", timeout=10).json()
    except Exception:
        return {"embedding": [], "llm": [], "defaults": {}}


def pick(options: list[str], default: str | None) -> int:
    for i, o in enumerate(options):
        if default and o.split(":")[0] == default.split(":")[0]:
            return i
    return 0


def wait_for_run(run_id: str) -> None:
    box = st.empty()
    while True:
        run = call("GET", f"/ingest/runs/{run_id}")
        box.json({"status": run["status"], **(run["stats"] or {})})
        if run["status"] != "running":
            break
        time.sleep(1)
    {"done": st.success, "done_with_errors": st.warning}.get(run["status"], st.error)(
        f"Ingest finished: {run['status']}" + (f" - {run['error']}" if run["error"] else ""))


def render(res: dict) -> None:
    c = st.columns(4)
    c[0].metric("Search confidence", f"{res['search_confidence']:.2f}")
    c[1].metric("Total time", f"{res['timings_ms']['total']:.0f} ms")
    c[2].metric("Returned", res["counts"]["returned"])
    c[3].metric("Candidates kw / sem", f"{res['counts']['keyword_candidates']} / {res['counts']['semantic_candidates']}")
    for w in res["warnings"]:
        st.warning(w)
    if res["answer"]:
        st.info(res["answer"])
    stage = {k: v for k, v in res["timings_ms"].items() if k != "total"}
    if stage:
        st.caption("Time per stage (ms)")
        st.bar_chart(pd.Series(stage, name="ms"))
    for r in res["results"]:
        cit = r["citation"]
        title = f"{cit['label']} {cit['title']} · score {r['score']} · confidence {r['confidence']}"
        with st.expander(title, expanded=r["rank"] <= 2):
            st.write(r["text"])
            st.caption(f"source: {cit['source']} · chunk {cit['chunk_index']} · page {cit['page']} · "
                       f"chars {cit['char_span'][0]}-{cit['char_span'][1]} · found by {', '.join(r['metadata']['found_by'])}")
            a, b = st.columns(2)
            a.json({"scores": r["scores"]})
            b.json({"ranks": r["ranks"]})
    with st.expander("Raw response JSON"):
        st.json(res)


SIGNALS = {
    "final": "Final score (what the mode ranks by)",
    "confidence": "Confidence (heuristic)",
    "rerank": "Rerank score",
    "semantic": "Semantic cosine",
    "keyword": "Keyword ts_rank_cd",
    "fused": "RRF / fused score",
}


def threshold_explorer(res: dict) -> None:
    st.subheader("🎯 Score threshold explorer")
    st.caption("Pick the cutoff that gives the recall you need. Uses your labelled queries: a document counts as "
               "returned if its score is at or above the cutoff. Relevant documents that were never retrieved "
               "still count against recall, so the *retrieval ceiling* is the best recall any cutoff can reach.")
    modes = list(res["summary"].keys())
    a = st.columns(3)
    mode = a[0].selectbox("Mode", modes, index=len(modes) - 1, key="thr_mode")
    signal = a[1].selectbox("Score to threshold", list(SIGNALS), format_func=SIGNALS.get, key="thr_signal")
    min_grade = a[2].selectbox("Relevant if grade ≥", [1, 2, 3], key="thr_grade")

    rows, total_rel = th.collect_rows(res["per_query"], mode, signal, min_grade)
    if not rows or not total_rel:
        st.info("No scored results for this combination (the rerank score needs a run with a reranker; "
                "keyword/semantic scores exist only for documents that retriever found).")
        return

    lo, hi = min(r["value"] for r in rows), max(r["value"] for r in rows)
    ceiling = th.metrics_at(rows, total_rel, lo)["recall"]
    target = st.slider("Target recall", 0.1, 1.0, min(0.9, max(ceiling, 0.1)), 0.05, key="thr_target")
    suggestion = th.cutoff_for_recall(rows, total_rel, target)
    default_cut = suggestion[0] if suggestion else lo
    if suggestion:
        st.success(f"Highest cutoff reaching {target:.0%} recall: **{suggestion[0]:.4f}** "
                   f"(precision {suggestion[1]['precision']:.0%}, {suggestion[1]['returned']} docs returned)")
    else:
        st.warning(f"{target:.0%} recall is unreachable: retrieval ceiling is {ceiling:.0%}. "
                   "Raise candidates, improve summaries, or change the embedding model.")

    step = max((hi - lo) / 200, 1e-6)
    cutoff = st.slider("Cutoff", float(lo), float(hi), float(default_cut), step,
                       key=f"thr_cut_{mode}_{signal}_{min_grade}_{target}", format="%.4f")
    m = th.metrics_at(rows, total_rel, cutoff)
    c = st.columns(5)
    c[0].metric("Precision", "n/a" if m["precision"] is None else f"{m['precision']:.0%}")
    c[1].metric("Recall", f"{m['recall']:.0%}")
    c[2].metric("F1", f"{m['f1']:.2f}")
    c[3].metric("Docs returned", m["returned"])
    c[4].metric("Retrieval ceiling", f"{ceiling:.0%}")

    left, right = st.columns(2)
    with left:
        st.caption("Score distribution: relevant vs irrelevant documents")
        st.bar_chart(pd.DataFrame(th.histogram(rows)), x="bin", y=["relevant", "irrelevant"],
                     color=["#2e9e5b", "#d9534f"])
    with right:
        st.caption("Precision and recall as the cutoff rises")
        sw = pd.DataFrame(th.sweep(rows, total_rel)).set_index("cutoff")[["precision", "recall"]]
        st.line_chart(sw)

    missed = [r for r in rows if r["relevant"] and r["value"] < cutoff]
    false_pos = [r for r in rows if not r["relevant"] and r["value"] >= cutoff]
    with st.expander(f"Relevant documents lost at this cutoff ({len(missed)})"):
        st.dataframe(pd.DataFrame(missed), width="stretch")
    with st.expander(f"Irrelevant documents still returned ({len(false_pos)})"):
        st.dataframe(pd.DataFrame(false_pos), width="stretch")


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.title("🔎 Hybrid Search Lab")
    try:
        h = requests.get(f"{API}/health", timeout=5).json()
    except Exception:
        h = {}
    st.write(f"API {'🟢' if h else '🔴'} · Postgres {'🟢' if h.get('db') else '🔴'} · "
             f"Ollama {'🟢' if h.get('ollama') else '🔴'}")
    models = get_models()
    d = models.get("defaults", {})
    emb_opts = models.get("embedding") or [d.get("embedding", "nomic-embed-text")]
    llm_opts = models.get("llm") or [d.get("llm", "llama3.2")]
    embed_model = st.selectbox("Embedding model", emb_opts, index=pick(emb_opts, d.get("embedding")))
    llm_model = st.selectbox("Language model (rerank / answer)", llm_opts, index=pick(llm_opts, d.get("llm")))
    reranker_model = st.text_input("Cross-encoder model", d.get("reranker", "cross-encoder/ms-marco-MiniLM-L-6-v2"))
    st.caption("Vectors are tied to the embedding model that created them. Re-ingest with *force* after switching.")

t_ing, t_search, t_cmp, t_eval, t_docs, t_logs = st.tabs(
    ["📥 Ingest", "🔍 Search", "⚖️ Compare modes", "📊 Evaluate", "📚 Documents", "🧾 Logs"])

# ------------------------------------------------------------------- ingest
with t_ing:
    c1, c2, c3 = st.columns(3)
    chunk_size = c1.number_input("Chunk size (words)", 20, 1000, 220, 10)
    overlap = c2.number_input("Chunk overlap (words)", 0, 300, 40, 5)
    force = c3.checkbox("Re-ingest even if unchanged")
    base = {"embed_model": embed_model, "chunk_size": int(chunk_size), "chunk_overlap": int(overlap)}
    left, right = st.columns(2)
    with left:
        files = st.file_uploader("Upload .txt / .md / .pdf", accept_multiple_files=True, type=["txt", "md", "pdf"])
        if st.button("Ingest uploaded files", disabled=not files):
            res = call("POST", "/ingest", files=[("files", (f.name, f.getvalue())) for f in files],
                       data={**base, "force": str(force).lower()})
            wait_for_run(res["run_id"])
    with right:
        folder = st.text_input("Folder under the API's /data mount", "sample")
        if st.button("Ingest folder"):
            res = call("POST", "/ingest/folder", json={**base, "path": folder, "force": force})
            wait_for_run(res["run_id"])

# ------------------------------------------------------------------- search
with t_search:
    q = st.text_input("Query", placeholder="e.g. how do I combine keyword and vector results?")
    a = st.columns(4)
    mode = a[0].selectbox("Mode", ["hybrid", "keyword", "semantic"])
    top_k = a[1].slider("Top K", 1, 20, 5)
    fusion = a[2].selectbox("Fusion (hybrid)", ["rrf", "weighted"])
    alpha = a[3].slider("Semantic weight α (weighted fusion)", 0.0, 1.0, 0.5, 0.05)
    b = st.columns(3)
    rerank = b[0].selectbox("Reranker", ["none", "cross_encoder", "llm"])
    cands = b[1].slider("Candidates per retriever", 10, 100, 50, 10)
    gen = b[2].checkbox("Generate answer with language model")
    d3 = st.columns(3)
    use_cut = d3[0].checkbox("Apply score cutoff")
    cut_signal = d3[1].selectbox("Cutoff on", ["score", "confidence", "rerank", "semantic", "keyword"],
                                 disabled=not use_cut, help="'score' = rerank score if reranked, else the mode's own score")
    cut_value = d3[2].number_input("Minimum value", 0.0, 10.0, 0.30, 0.01, disabled=not use_cut, format="%.4f")
    if st.button("Search", type="primary", disabled=not q.strip()):
        res = call("POST", "/search", json={
            "query": q, "mode": mode, "top_k": top_k, "fusion": fusion, "alpha": alpha, "rerank": rerank,
            "candidates": cands, "embed_model": embed_model, "llm_model": llm_model,
            "reranker_model": reranker_model, "generate_answer": gen,
            "min_score": cut_value if use_cut else None, "min_score_signal": cut_signal})
        render(res)

# ------------------------------------------------------------------ compare
with t_cmp:
    cq = st.text_input("Query to compare", key="cmp_q")
    ck = st.slider("Top K", 1, 10, 5, key="cmp_k")
    if st.button("Compare keyword vs semantic vs hybrid", disabled=not cq.strip()):
        cols = st.columns(3)
        ids = {}
        for col, m in zip(cols, ["keyword", "semantic", "hybrid"]):
            res = call("POST", "/search", json={"query": cq, "mode": m, "top_k": ck, "embed_model": embed_model})
            ids[m] = [r["chunk_id"] for r in res["results"]]
            with col:
                st.subheader(m)
                st.caption(f"confidence {res['search_confidence']:.2f} · {res['timings_ms']['total']:.0f} ms")
                for r in res["results"]:
                    st.markdown(f"**{r['rank']}. {r['citation']['title']}**  \n"
                                f"score {r['score']} · kw#{r['ranks']['keyword']} · sem#{r['ranks']['semantic']}")
        inter, union = set(ids["keyword"]) & set(ids["semantic"]), set(ids["keyword"]) | set(ids["semantic"])
        st.metric("Keyword/semantic overlap (Jaccard)", f"{len(inter) / len(union):.2f}" if union else "n/a")

# ----------------------------------------------------------------- evaluate
with t_eval:
    st.write("Provide labelled queries: each maps document titles (file names without extension) to graded "
             "relevance 1-3. Metrics are computed at document level.")
    spec_text = st.text_area("Eval set (JSON)", json.dumps(SAMPLE_EVAL, indent=2), height=260)
    e = st.columns(4)
    ek = e[0].slider("k", 1, 20, 5, key="eval_k")
    er = e[1].selectbox("Add reranked hybrid run", ["none", "cross_encoder", "llm"], key="eval_r")
    ef = e[2].selectbox("Fusion", ["rrf", "weighted"], key="eval_f")
    ea = e[3].slider("α", 0.0, 1.0, 0.5, 0.05, key="eval_a")
    if st.button("Run evaluation", type="primary"):
        try:
            spec = json.loads(spec_text)
            queries = spec["queries"]
        except (json.JSONDecodeError, KeyError, TypeError) as ex:
            st.error(f"Invalid eval set: {ex}")
        else:
            st.session_state["eval_res"] = call("POST", "/eval/run", json={
                "queries": queries, "k": ek, "rerank": er, "fusion": ef, "alpha": ea,
                "embed_model": embed_model, "llm_model": llm_model, "reranker_model": reranker_model})

    res = st.session_state.get("eval_res")
    if res:
        k = res["k"]
        df = pd.DataFrame(res["summary"]).T
        st.subheader(f"Summary over {res['n_queries']} queries (k={k})")
        st.dataframe(df, width="stretch")
        st.bar_chart(df[[f"ndcg@{k}", "mrr", f"recall@{k}", f"precision@{k}"]])
        st.metric("Keyword/semantic overlap (Jaccard of top-k docs)", res["keyword_semantic_overlap"])
        rows = [{"query": pq["query"], "mode": m, **{key: v for key, v in d.items() if key not in ("ranked", "scored")},
                 "ranked": ", ".join(d["ranked"])} for pq in res["per_query"] for m, d in pq["modes"].items()]
        st.subheader("Per query")
        st.dataframe(pd.DataFrame(rows), width="stretch")
        st.divider()
        threshold_explorer(res)

# ---------------------------------------------------------------- documents
with t_docs:
    docs = call("GET", "/documents")
    if docs:
        st.dataframe(pd.DataFrame(docs), width="stretch")
        target = st.selectbox("Delete a document", [""] + [f"{d['title']} ({d['id']})" for d in docs])
        if target and st.button("Delete", type="secondary"):
            call("DELETE", f"/documents/{target.rsplit('(', 1)[1].rstrip(')')}")
            st.rerun()
    else:
        st.info("No documents yet. Use the Ingest tab.")

# --------------------------------------------------------------------- logs
with t_logs:
    logs = call("GET", "/search/logs", params={"limit": 50})
    if logs:
        st.dataframe(pd.json_normalize(logs, sep="."), width="stretch")
    else:
        st.info("No searches logged yet.")
