import asyncio
import re
import time

import numpy as np
from psycopg.types.json import Jsonb

from .config import settings
from .db import pool
from .metrics import jaccard
from .ollama_client import norm_model, ollama
from .rerank import rerank_scores
from .schemas import SearchRequest
from .timing import Timings

_COLS = """c.id, c.content, c.chunk_index, c.page, c.char_start, c.char_end,
       d.id AS document_id, d.title, d.source"""

# ts_rank_cd normalisation flag 32 => rank / (rank + 1), bounded in [0, 1)
KEYWORD_AND_SQL = f"""
SELECT {_COLS}, ts_rank_cd(c.tsv, q, 32) AS score
FROM chunks c JOIN documents d ON d.id = c.document_id,
     websearch_to_tsquery('english', %(q)s) AS q
WHERE c.tsv @@ q
ORDER BY score DESC
LIMIT %(limit)s
"""

KEYWORD_OR_SQL = f"""
SELECT {_COLS}, ts_rank_cd(c.tsv, q, 32) AS score
FROM chunks c JOIN documents d ON d.id = c.document_id,
     to_tsquery('english', %(q)s) AS q
WHERE c.tsv @@ q
ORDER BY score DESC
LIMIT %(limit)s
"""

SEMANTIC_SQL = f"""
SELECT {_COLS}, 1 - (c.embedding <=> %(emb)s) AS score
FROM chunks c JOIN documents d ON d.id = c.document_id
WHERE c.embed_model = %(model)s
ORDER BY c.embedding <=> %(emb)s
LIMIT %(limit)s
"""


# ---------------------------------------------------------------- retrievers
async def keyword_search(query: str, limit: int) -> tuple[list[dict], str]:
    """Full-text search. Strict AND first; falls back to OR when nothing matches."""
    async with pool.connection() as conn:
        cur = await conn.execute(KEYWORD_AND_SQL, {"q": query, "limit": limit})
        rows = await cur.fetchall()
        used = "and"
        if not rows:
            words = sorted({w.lower() for w in re.findall(r"\w+", query)})
            if words:
                cur = await conn.execute(KEYWORD_OR_SQL, {"q": " | ".join(words), "limit": limit})
                rows = await cur.fetchall()
                used = "or"
    return rows, used


async def semantic_search(embedding: list[float], model: str, limit: int) -> list[dict]:
    vec = np.asarray(embedding, dtype=np.float32)
    async with pool.connection() as conn:
        cur = await conn.execute(SEMANTIC_SQL, {"emb": vec, "model": model, "limit": limit})
        return await cur.fetchall()


# -------------------------------------------------------------------- fusion
def build_candidates(kw_rows: list[dict], sem_rows: list[dict]) -> list[dict]:
    cands: dict[int, dict] = {}
    for rank, row in enumerate(kw_rows, 1):
        c = cands.setdefault(row["id"], {"row": row})
        c["kw_score"], c["kw_rank"] = float(row["score"]), rank
    for rank, row in enumerate(sem_rows, 1):
        c = cands.setdefault(row["id"], {"row": row})
        c["sem_score"], c["sem_rank"] = float(row["score"]), rank
    return list(cands.values())


def _minmax(values: list[float]):
    lo, hi = min(values), max(values)
    return lambda v: 1.0 if hi == lo else (v - lo) / (hi - lo)


def order_candidates(cands: list[dict], req: SearchRequest) -> list[dict]:
    """Assigns c['base'] (the retrieval-stage score) and sorts best-first."""
    if req.mode == "keyword":
        for c in cands:
            c["base"] = c["kw_score"]
    elif req.mode == "semantic":
        for c in cands:
            c["base"] = c["sem_score"]
    elif req.fusion == "rrf":
        for c in cands:
            c["base"] = sum(1.0 / (req.rrf_k + c[r]) for r in ("kw_rank", "sem_rank") if r in c)
    else:  # weighted: min-max normalise each retriever, then blend
        kws = [c["kw_score"] for c in cands if "kw_score" in c]
        sems = [c["sem_score"] for c in cands if "sem_score" in c]
        nk = _minmax(kws) if kws else (lambda v: 0.0)
        ns = _minmax(sems) if sems else (lambda v: 0.0)
        for c in cands:
            k = nk(c["kw_score"]) if "kw_score" in c else 0.0
            s = ns(c["sem_score"]) if "sem_score" in c else 0.0
            c["base"] = req.alpha * s + (1 - req.alpha) * k
    cands.sort(key=lambda c: c["base"], reverse=True)
    return cands


# ---------------------------------------------------------------- confidence
def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def relevance_of(c: dict) -> float:
    """Absolute (not rank-relative) relevance estimate in [0, 1]."""
    if "rerank_score" in c:
        return c["rerank_score"]
    vals = []
    if "kw_score" in c:
        vals.append(_clamp(c["kw_score"] / settings.kw_ceiling))
    if "sem_score" in c:
        vals.append(_clamp((c["sem_score"] - settings.sem_floor) / (settings.sem_ceiling - settings.sem_floor)))
    return max(vals) if vals else 0.0


def confidence_of(c: dict, mode: str) -> float:
    rel = relevance_of(c)
    if mode == "hybrid":
        agree = 1.0 if ("kw_rank" in c and "sem_rank" in c) else 0.5
        return 0.75 * rel + 0.25 * agree
    return rel


def signal_value(c: dict, name: str, mode: str, reranked: bool):
    """Value of a named score for a candidate (None when that signal doesn't exist for it)."""
    if name == "score":
        return c["rerank_score"] if reranked and "rerank_score" in c else c["base"]
    if name == "confidence":
        return confidence_of(c, mode)
    if name == "rerank":
        return c.get("rerank_score")
    if name == "semantic":
        return c.get("sem_score")
    if name == "keyword":
        return c.get("kw_score")
    raise ValueError(f"unknown score signal: {name}")


def search_confidence(results: list[dict], mode: str, kw_rows: list[dict], sem_rows: list[dict], k: int) -> float:
    """Heuristic 0-1 confidence for the whole result set (see docs/EVALUATION.md)."""
    if not results:
        return 0.0
    top = results[0]["confidence"]
    second = results[1]["confidence"] if len(results) > 1 else 0.0
    margin = _clamp(top - second, 0.0, 0.3) / 0.3
    if mode == "hybrid":
        overlap = jaccard([r["id"] for r in kw_rows[:k]], [r["id"] for r in sem_rows[:k]])
    else:
        overlap = top
    return round(_clamp(0.7 * top + 0.15 * margin + 0.15 * overlap), 3)


# -------------------------------------------------------------------- output
def _round(x, n=4):
    return None if x is None else round(float(x), n)


def format_result(c: dict, rank: int, mode: str, reranked: bool) -> dict:
    row = c["row"]
    found_by = [n for n, key in (("keyword", "kw_rank"), ("semantic", "sem_rank")) if key in c]
    return {
        "rank": rank,
        "chunk_id": row["id"],
        "text": row["content"],
        "score": _round(c["rerank_score"] if reranked and "rerank_score" in c else c["base"]),
        "scores": {
            "keyword": _round(c.get("kw_score")),
            "semantic": _round(c.get("sem_score")),
            "fused": _round(c["base"]) if mode == "hybrid" else None,
            "rerank": _round(c.get("rerank_score")),
        },
        "ranks": {
            "keyword": c.get("kw_rank"),
            "semantic": c.get("sem_rank"),
            "fused": c.get("fused_rank"),
            "final": rank,
        },
        "confidence": _round(confidence_of(c, mode), 3),
        "citation": {
            "label": f"[{rank}]",
            "document_id": str(row["document_id"]),
            "title": row["title"],
            "source": row["source"],
            "chunk_index": row["chunk_index"],
            "page": row["page"],
            "char_span": [row["char_start"], row["char_end"]],
        },
        "metadata": {"found_by": found_by},
    }


async def generate_answer(llm: str, query: str, results: list[dict]) -> str:
    context = "\n\n".join(f"[{r['rank']}] ({r['citation']['title']}) {r['text']}" for r in results)
    system = ("Answer the question using ONLY the numbered context passages. Cite passages inline "
              "like [1]. If the context does not contain the answer, say so.")
    return await ollama.chat(llm, [{"role": "system", "content": system},
                                   {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {query}"}],
                             temperature=0.2)


async def _log_search(req: SearchRequest, timings: dict, conf: float, results: list[dict]) -> int | None:
    try:
        async with pool.connection() as conn:
            cur = await conn.execute(
                "INSERT INTO search_logs (query, mode, params, timings, search_confidence, n_results, result_chunk_ids) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id",
                (req.query, req.mode, Jsonb(req.model_dump()), Jsonb(timings), conf, len(results),
                 [r["chunk_id"] for r in results]),
            )
            return (await cur.fetchone())["id"]
    except Exception:  # logging must never break search
        return None


# ---------------------------------------------------------------------- main
async def run_search(req: SearchRequest) -> dict:
    t = Timings()
    t_start = time.perf_counter()
    warnings: list[str] = []
    embed_model = norm_model(req.embed_model or settings.embed_model)
    use_kw = req.mode in ("keyword", "hybrid")
    use_sem = req.mode in ("semantic", "hybrid")

    q_emb = None
    if use_sem:
        with t.measure("query_embedding"):
            q_emb = (await ollama.embed(embed_model, [req.query], kind="query"))[0]

    kw_query_mode: str | None = None

    async def _kw():
        nonlocal kw_query_mode
        with t.measure("keyword_search"):
            rows, kw_query_mode = await keyword_search(req.query, req.candidates)
        return rows

    async def _sem():
        with t.measure("semantic_search"):
            return await semantic_search(q_emb, embed_model, req.candidates)

    async def _none():
        return []

    kw_rows, sem_rows = await asyncio.gather(_kw() if use_kw else _none(), _sem() if use_sem else _none())

    with t.measure("fusion"):
        cands = order_candidates(build_candidates(kw_rows, sem_rows), req)
        if req.mode == "hybrid":
            for i, c in enumerate(cands, 1):
                c["fused_rank"] = i
    n_candidates = len(cands)

    reranked = False
    reranker_used = None
    if req.rerank != "none" and cands:
        pool_ = cands[: req.rerank_candidates]
        reranker_used = req.reranker_model or settings.reranker_model if req.rerank == "cross_encoder" \
            else req.llm_model or settings.default_llm
        try:
            with t.measure("rerank"):
                scores = await rerank_scores(req.rerank, req.query, [c["row"]["content"] for c in pool_],
                                             req.reranker_model or settings.reranker_model,
                                             req.llm_model or settings.default_llm)
            for c, s in zip(pool_, scores):
                c["rerank_score"] = s
            cands = sorted(pool_, key=lambda c: (c["rerank_score"], c["base"]), reverse=True)
            reranked = True
        except Exception as e:  # degrade gracefully, keep retrieval order
            warnings.append(f"rerank skipped ({type(e).__name__}): {e}")

    filtered_out = 0
    if req.min_score is not None:
        kept = []
        for c in cands:
            v = signal_value(c, req.min_score_signal, req.mode, reranked)
            if v is not None and v >= req.min_score:
                kept.append(c)
        filtered_out = len(cands) - len(kept)
        if cands and not kept and req.min_score_signal == "rerank" and not reranked:
            warnings.append("min_score_signal is 'rerank' but no reranker ran, so nothing can pass")
        cands = kept

    final = cands[: req.top_k]
    results = [format_result(c, i, req.mode, reranked) for i, c in enumerate(final, 1)]
    conf = search_confidence(results, req.mode, kw_rows, sem_rows, req.top_k)

    answer = None
    llm = req.llm_model or settings.default_llm
    if req.generate_answer and results:
        try:
            with t.measure("generation"):
                answer = await generate_answer(llm, req.query, results)
        except Exception as e:
            warnings.append(f"answer generation failed ({type(e).__name__}): {e}")

    t.ms["total"] = (time.perf_counter() - t_start) * 1000
    timings = t.as_dict()
    search_id = await _log_search(req, timings, conf, results) if req.log else None

    return {
        "search_id": search_id,
        "query": req.query,
        "mode": req.mode,
        "search_confidence": conf,
        "results": results,
        "answer": answer,
        "timings_ms": timings,
        "models": {
            "embedding": embed_model if use_sem else None,
            "reranker": reranker_used if reranked else None,
            "llm": llm if answer else None,
        },
        "counts": {"keyword_candidates": len(kw_rows), "semantic_candidates": len(sem_rows),
                   "merged_candidates": n_candidates, "filtered_by_min_score": filtered_out,
                   "returned": len(results)},
        "params": {"fusion": req.fusion if req.mode == "hybrid" else None,
                   "alpha": req.alpha if req.mode == "hybrid" and req.fusion == "weighted" else None,
                   "rrf_k": req.rrf_k if req.mode == "hybrid" and req.fusion == "rrf" else None,
                   "keyword_query_mode": kw_query_mode, "reranked": reranked,
                   "min_score": req.min_score, "min_score_signal": req.min_score_signal if req.min_score is not None else None},
        "warnings": warnings,
    }
