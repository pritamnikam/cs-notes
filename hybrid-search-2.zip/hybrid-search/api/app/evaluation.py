import json
from collections import defaultdict

import numpy as np
from psycopg.types.json import Jsonb

from . import metrics
from .db import pool
from .schemas import EvalRequest, SearchRequest
from .search import run_search


def _doc_ranking(results: list[dict]) -> list[str]:
    """Collapse chunk results to a ranked list of unique document titles."""
    seen, ranked = set(), []
    for r in results:
        title = r["citation"]["title"]
        if title not in seen:
            seen.add(title)
            ranked.append(title)
    return ranked


def _scored(results: list[dict], rel: dict[str, int]) -> list[dict]:
    """Per-document score signals (best chunk per doc) with the human relevance grade attached."""
    seen: set[str] = set()
    out = []
    for r in results:
        title = r["citation"]["title"]
        if title in seen:
            continue
        seen.add(title)
        out.append({"doc": title, "grade": rel.get(title, 0), "rank": len(out) + 1, "signals": {
            "final": r["score"], "confidence": r["confidence"], "rerank": r["scores"]["rerank"],
            "semantic": r["scores"]["semantic"], "keyword": r["scores"]["keyword"],
            "fused": r["scores"]["fused"]}})
    return out


async def run_eval(req: EvalRequest) -> dict:
    configs = [("keyword", {"mode": "keyword"}), ("semantic", {"mode": "semantic"}), ("hybrid", {"mode": "hybrid"})]
    if req.rerank != "none":
        configs.append(("hybrid+rerank", {"mode": "hybrid", "rerank": req.rerank}))

    agg: dict[str, dict[str, list[float]]] = {name: defaultdict(list) for name, _ in configs}
    per_query, overlaps = [], []

    for q in req.queries:
        row = {"query": q.query, "relevant": q.relevant, "modes": {}}
        rankings: dict[str, list[str]] = {}
        for name, extra in configs:
            sr = SearchRequest(
                query=q.query, top_k=min(50, req.k * 3), rerank_candidates=max(30, req.k * 3),
                fusion=req.fusion, alpha=req.alpha, embed_model=req.embed_model,
                reranker_model=req.reranker_model, llm_model=req.llm_model, log=False, **extra)
            resp = await run_search(sr)
            ranked = _doc_ranking(resp["results"])[: req.k]
            rankings[name] = ranked
            m = metrics.all_metrics(ranked, q.relevant, req.k)
            m["latency_ms"] = resp["timings_ms"]["total"]
            m["search_confidence"] = resp["search_confidence"]
            for key, val in m.items():
                agg[name][key].append(val)
            row["modes"][name] = {"ranked": ranked, "scored": _scored(resp["results"], q.relevant),
                                  **{k: round(v, 4) for k, v in m.items()}}
        overlaps.append(metrics.jaccard(rankings["keyword"], rankings["semantic"]))
        per_query.append(row)

    summary = {}
    for name, cols in agg.items():
        lat = cols.pop("latency_ms")
        summary[name] = {k: round(float(np.mean(v)), 4) for k, v in cols.items()}
        summary[name]["latency_p50_ms"] = round(float(np.percentile(lat, 50)), 1)
        summary[name]["latency_p95_ms"] = round(float(np.percentile(lat, 95)), 1)

    result = {"k": req.k, "n_queries": len(req.queries), "summary": summary,
              "keyword_semantic_overlap": round(float(np.mean(overlaps)), 4), "per_query": per_query}
    try:
        async with pool.connection() as conn:
            await conn.execute("INSERT INTO eval_runs (config, summary) VALUES (%s,%s)",
                               (Jsonb(json.loads(req.model_dump_json(exclude={"queries"}))), Jsonb(summary)))
    except Exception:
        pass
    return result
