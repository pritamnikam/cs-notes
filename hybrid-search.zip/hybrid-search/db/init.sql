CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS documents (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title        TEXT NOT NULL,
    source       TEXT,
    content_hash TEXT NOT NULL UNIQUE,          -- idempotent ingestion
    metadata     JSONB NOT NULL DEFAULT '{}',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- NOTE: vector(768) matches nomic-embed-text. Change it (and EMBED_DIM) for other models.
CREATE TABLE IF NOT EXISTS chunks (
    id          BIGSERIAL PRIMARY KEY,
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INT  NOT NULL,
    content     TEXT NOT NULL,
    char_start  INT,
    char_end    INT,
    page        INT,
    tsv         TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    embedding   vector(768),
    embed_model TEXT NOT NULL,                  -- never mix vectors from different models
    metadata    JSONB NOT NULL DEFAULT '{}',
    UNIQUE (document_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS chunks_tsv_gin   ON chunks USING GIN (tsv);
CREATE INDEX IF NOT EXISTS chunks_emb_hnsw  ON chunks USING hnsw (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS chunks_doc_idx   ON chunks (document_id);

CREATE TABLE IF NOT EXISTS ingest_runs (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status      TEXT NOT NULL,
    params      JSONB,
    stats       JSONB,
    error       TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS search_logs (
    id                BIGSERIAL PRIMARY KEY,
    query             TEXT NOT NULL,
    mode              TEXT,
    params            JSONB,
    timings           JSONB,
    search_confidence REAL,
    n_results         INT,
    result_chunk_ids  BIGINT[],
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS eval_runs (
    id         BIGSERIAL PRIMARY KEY,
    config     JSONB,
    summary    JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
