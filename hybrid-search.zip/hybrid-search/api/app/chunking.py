import re

_WORD = re.compile(r"\S+")


def chunk_text(text: str, size: int, overlap: int) -> list[tuple[int, int, str]]:
    """Sliding word-window chunker. Returns (char_start, char_end, text) tuples."""
    if size <= 0:
        raise ValueError("size must be > 0")
    overlap = max(0, min(overlap, size - 1))
    words = [(m.start(), m.end()) for m in _WORD.finditer(text)]
    step = size - overlap
    chunks: list[tuple[int, int, str]] = []
    for i in range(0, len(words), step):
        window = words[i : i + size]
        if not window:
            break
        start, end = window[0][0], window[-1][1]
        chunks.append((start, end, text[start:end]))
        if i + size >= len(words):
            break
    return chunks
