from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from . import ingest as ing
from .config import settings
from .db import pool
from .evaluation import run_eval
from .ollama_client import norm_model, ollama
from .schemas import EvalRequest, IngestFolderRequest, SearchRequest
from .search import run_search

EMBED_HINTS = ("embed", "bge", "e5", "minilm", "gte", "arctic")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await pool.open(wait=True, timeout=30)
    await ollama.start()
    yield
    await ollama.stop()
    await pool.close()


app = FastAPI(title="Hybrid Search API", version="1.0.0", lifespan=lifespan)


@app.exception_handler(httpx.HTTPError)
async def ollama_error(_, exc: httpx.HTTPError):
    return JSONResponse(status_code=502, content={"detail": f"Ollama request failed: {exc!r}"})


def _ingest_opts(embed_model, chunk_size, chunk_overlap, force) -> dict:
    return {"embed_model": norm_model(embed_model or settings.embed_model),
            "chunk_size": chunk_size or settings.chunk_size,
            "chunk_overlap": settings.chunk_overlap if chunk_overlap is None else chunk_overlap,
            "force": force}


# ------------------------------------------------------------------ system
@app.get("/health")
async def health():
    out = {"db": False, "ollama": False, "embed_model": settings.embed_model}
    try:
        async with pool.connection() as conn:
            await conn.execute("SELECT 1")
        out["db"] = True
    except Exception as e:
        out["db_error"] = str(e)
    try:
        out["ollama_models"] = len(await ollama.tags())
        out["ollama"] = True
    except Exception as e:
        out["ollama_error"] = repr(e)
    return out


@app.get("/models")
async def models():
    names = await ollama.tags()
    emb = [n for n in names if any(h in n.lower() for h in EMBED_HINTS)]
    return {"all": names, "embedding": emb or names, "llm": [n for n in names if n not in emb] or names,
            "defaults": {"embedding": settings.embed_model, "llm": settings.default_llm,
                         "reranker": settings.reranker_model}}


# ------------------------------------------------------------------ ingest
@app.post("/ingest", status_code=202)
async def ingest_files(background: BackgroundTasks, files: list[UploadFile] = File(...),
                       embed_model: str | None = Form(None), chunk_size: int | None = Form(None),
                       chunk_overlap: int | None = Form(None), force: bool = Form(False)):
    opts = _ingest_opts(embed_model, chunk_size, chunk_overlap, force)
    items = [(f.filename or "upload", await f.read()) for f in files]
    run_id = await ing.create_run({**opts, "files": [n for n, _ in items]})
    background.add_task(ing.run_ingest, run_id, items, None, opts)
    return {"run_id": run_id}


@app.post("/ingest/folder", status_code=202)
async def ingest_folder(req: IngestFolderRequest, background: BackgroundTasks):
    root = Path(settings.data_dir).resolve()
    target = (root / req.path).resolve()
    if not target.is_relative_to(root) or not target.is_dir():
        raise HTTPException(400, f"path must be an existing folder under {root}")
    opts = _ingest_opts(req.embed_model, req.chunk_size, req.chunk_overlap, req.force)
    run_id = await ing.create_run({**opts, "folder": str(target)})
    background.add_task(ing.run_ingest, run_id, None, str(target), opts)
    return {"run_id": run_id}


@app.get("/ingest/runs")
async def list_runs(limit: int = 20):
    async with pool.connection() as conn:
        cur = await conn.execute("SELECT * FROM ingest_runs ORDER BY created_at DESC LIMIT %s", (limit,))
        return [{**r, "id": str(r["id"])} for r in await cur.fetchall()]


@app.get("/ingest/runs/{run_id}")
async def get_run(run_id: str):
    async with pool.connection() as conn:
        cur = await conn.execute("SELECT * FROM ingest_runs WHERE id=%s", (run_id,))
        row = await cur.fetchone()
    if not row:
        raise HTTPException(404, "run not found")
    return {**row, "id": str(row["id"])}


# --------------------------------------------------------------- documents
@app.get("/documents")
async def list_documents():
    async with pool.connection() as conn:
        cur = await conn.execute(
            "SELECT d.id, d.title, d.source, d.created_at, count(c.id) AS chunks, "
            "min(c.embed_model) AS embed_model FROM documents d LEFT JOIN chunks c ON c.document_id=d.id "
            "GROUP BY d.id ORDER BY d.created_at DESC")
        return [{**r, "id": str(r["id"])} for r in await cur.fetchall()]


@app.delete("/documents/{doc_id}")
async def delete_document(doc_id: str):
    async with pool.connection() as conn:
        cur = await conn.execute("DELETE FROM documents WHERE id=%s RETURNING id", (doc_id,))
        if not await cur.fetchone():
            raise HTTPException(404, "document not found")
    return {"deleted": doc_id}


# ------------------------------------------------------------------ search
@app.post("/search")
async def search(req: SearchRequest):
    return await run_search(req)


@app.get("/search/logs")
async def search_logs(limit: int = 25):
    async with pool.connection() as conn:
        cur = await conn.execute(
            "SELECT id, query, mode, search_confidence, n_results, timings, created_at "
            "FROM search_logs ORDER BY id DESC LIMIT %s", (limit,))
        return await cur.fetchall()


@app.post("/eval/run")
async def evaluate(req: EvalRequest):
    return await run_eval(req)
