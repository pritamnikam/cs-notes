import hashlib
import io
import time
from pathlib import Path

import numpy as np
from psycopg.types.json import Jsonb
from pypdf import PdfReader

from .chunking import chunk_text
from .config import settings
from .db import pool
from .ollama_client import ollama

SUPPORTED = {".txt", ".md", ".pdf"}


def extract_pages(filename: str, data: bytes) -> list[tuple[int | None, str]]:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf":
        reader = PdfReader(io.BytesIO(data))
        return [(i + 1, p.extract_text() or "") for i, p in enumerate(reader.pages)]
    if ext in {".txt", ".md"}:
        return [(None, data.decode("utf-8", errors="replace"))]
    raise ValueError(f"unsupported file type: {ext or '(none)'}")


async def create_run(params: dict) -> str:
    async with pool.connection() as conn:
        cur = await conn.execute(
            "INSERT INTO ingest_runs (status, params) VALUES ('running', %s) RETURNING id", (Jsonb(params),))
        return str((await cur.fetchone())["id"])


async def _update_run(run_id: str, stats: dict, status: str | None = None, error: str | None = None) -> None:
    async with pool.connection() as conn:
        if status:
            await conn.execute(
                "UPDATE ingest_runs SET status=%s, stats=%s, error=%s, finished_at=now() WHERE id=%s",
                (status, Jsonb(stats), error, run_id))
        else:
            await conn.execute("UPDATE ingest_runs SET stats=%s WHERE id=%s", (Jsonb(stats), run_id))


async def _ingest_one(filename: str, data: bytes, opts: dict, stats: dict) -> None:
    pages = extract_pages(filename, data)
    full_text = "\n\n".join(t for _, t in pages)
    if not full_text.strip():
        stats["skipped"].append({"file": filename, "reason": "no extractable text"})
        return
    content_hash = hashlib.sha256(full_text.encode()).hexdigest()

    async with pool.connection() as conn:
        cur = await conn.execute("SELECT id FROM documents WHERE content_hash=%s", (content_hash,))
        existing = await cur.fetchone()
        if existing and not opts["force"]:
            stats["skipped"].append({"file": filename, "reason": "already ingested (same content hash)"})
            return
        if existing:
            await conn.execute("DELETE FROM documents WHERE id=%s", (existing["id"],))

    pieces = [(page, s, e, txt) for page, text in pages
              for s, e, txt in chunk_text(text, opts["chunk_size"], opts["chunk_overlap"])]

    embeddings: list[list[float]] = []
    t0 = time.perf_counter()
    bs = settings.embed_batch_size
    for i in range(0, len(pieces), bs):
        embeddings.extend(await ollama.embed(opts["embed_model"], [p[3] for p in pieces[i:i + bs]],
                                             kind="document"))
    stats["embed_ms"] = round(stats["embed_ms"] + (time.perf_counter() - t0) * 1000, 1)
    if embeddings and len(embeddings[0]) != settings.embed_dim:
        raise ValueError(f"embedding dim {len(embeddings[0])} != EMBED_DIM {settings.embed_dim}; "
                         "update vector(N) in db/init.sql and EMBED_DIM")

    async with pool.connection() as conn:
        cur = await conn.execute(
            "INSERT INTO documents (title, source, content_hash, metadata) VALUES (%s,%s,%s,%s) RETURNING id",
            (Path(filename).stem, filename, content_hash, Jsonb({"pages": len(pages)})))
        doc_id = (await cur.fetchone())["id"]
        rows = [(doc_id, i, txt, s, e, page, np.asarray(emb, dtype=np.float32), opts["embed_model"])
                for i, ((page, s, e, txt), emb) in enumerate(zip(pieces, embeddings))]
        async with conn.cursor() as c2:
            await c2.executemany(
                "INSERT INTO chunks (document_id, chunk_index, content, char_start, char_end, page, "
                "embedding, embed_model) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", rows)
    stats["documents"] += 1
    stats["chunks"] += len(pieces)


async def run_ingest(run_id: str, items: list[tuple[str, bytes]] | None, folder: str | None, opts: dict) -> None:
    stats = {"files": 0, "documents": 0, "chunks": 0, "embed_ms": 0.0, "skipped": [], "errors": []}
    t0 = time.perf_counter()
    try:
        if folder:
            root = Path(folder)
            items = [(str(p.relative_to(root)), p.read_bytes())
                     for p in sorted(root.rglob("*")) if p.is_file() and p.suffix.lower() in SUPPORTED]
        for name, data in items or []:
            stats["files"] += 1
            try:
                await _ingest_one(name, data, opts, stats)
            except Exception as e:
                stats["errors"].append({"file": name, "error": f"{type(e).__name__}: {e}"})
            await _update_run(run_id, stats)
        stats["total_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        await _update_run(run_id, stats, "done_with_errors" if stats["errors"] else "done")
    except Exception as e:
        await _update_run(run_id, stats, "failed", f"{type(e).__name__}: {e}")
