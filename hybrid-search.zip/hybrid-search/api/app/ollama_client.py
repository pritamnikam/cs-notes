import httpx

from .config import settings


def norm_model(name: str) -> str:
    """Ollama lists models as name:latest; store/compare without the implicit tag."""
    return name[: -len(":latest")] if name.endswith(":latest") else name


def with_prefix(model: str, text: str, kind: str) -> str:
    """nomic-embed-text expects task prefixes; other models get raw text."""
    if "nomic" in model.lower():
        return ("search_query: " if kind == "query" else "search_document: ") + text
    return text


class OllamaClient:
    def __init__(self) -> None:
        self._client: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self._client = httpx.AsyncClient(base_url=settings.ollama_url, timeout=settings.ollama_timeout)

    async def stop(self) -> None:
        if self._client:
            await self._client.aclose()

    async def embed(self, model: str, texts: list[str], kind: str = "document") -> list[list[float]]:
        payload = [with_prefix(model, t, kind) for t in texts]
        r = await self._client.post("/api/embed", json={"model": model, "input": payload})
        r.raise_for_status()
        return r.json()["embeddings"]

    async def chat(self, model: str, messages: list[dict], json_mode: bool = False,
                   temperature: float = 0.0) -> str:
        body: dict = {"model": model, "messages": messages, "stream": False,
                      "options": {"temperature": temperature}}
        if json_mode:
            body["format"] = "json"
        r = await self._client.post("/api/chat", json=body)
        r.raise_for_status()
        return r.json()["message"]["content"]

    async def tags(self) -> list[str]:
        r = await self._client.get("/api/tags")
        r.raise_for_status()
        return sorted(m["name"] for m in r.json().get("models", []))


ollama = OllamaClient()
