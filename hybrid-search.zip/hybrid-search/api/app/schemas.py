from typing import Literal

from pydantic import BaseModel, Field


class SearchRequest(BaseModel):
    query: str = Field(min_length=1)
    mode: Literal["keyword", "semantic", "hybrid"] = "hybrid"
    top_k: int = Field(5, ge=1, le=50)
    candidates: int = Field(50, ge=1, le=200, description="candidates fetched per retriever")
    fusion: Literal["rrf", "weighted"] = "rrf"
    alpha: float = Field(0.5, ge=0, le=1, description="semantic weight for weighted fusion")
    rrf_k: int = Field(60, ge=1)
    rerank: Literal["none", "cross_encoder", "llm"] = "none"
    rerank_candidates: int = Field(30, ge=1, le=100)
    reranker_model: str | None = None
    embed_model: str | None = None
    llm_model: str | None = None
    generate_answer: bool = False
    log: bool = True


class IngestFolderRequest(BaseModel):
    path: str = "."
    embed_model: str | None = None
    chunk_size: int | None = Field(None, ge=10, le=2000)
    chunk_overlap: int | None = Field(None, ge=0, le=500)
    force: bool = False


class EvalQuery(BaseModel):
    query: str
    relevant: dict[str, int] = Field(description="document title -> graded relevance (1-3)")


class EvalRequest(BaseModel):
    queries: list[EvalQuery] = Field(min_length=1)
    k: int = Field(5, ge=1, le=20)
    fusion: Literal["rrf", "weighted"] = "rrf"
    alpha: float = Field(0.5, ge=0, le=1)
    rerank: Literal["none", "cross_encoder", "llm"] = "none"
    embed_model: str | None = None
    reranker_model: str | None = None
    llm_model: str | None = None
