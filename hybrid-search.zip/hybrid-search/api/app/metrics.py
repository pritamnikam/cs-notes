"""Pure-Python IR metrics. `ranked` = ordered doc ids; `rel` = {doc_id: graded relevance}."""
import math


def _relevant(rel: dict[str, int]) -> set[str]:
    return {d for d, g in rel.items() if g > 0}


def recall_at_k(ranked, rel, k):
    r = _relevant(rel)
    return len(set(ranked[:k]) & r) / len(r) if r else 0.0


def precision_at_k(ranked, rel, k):
    r = _relevant(rel)
    return len([d for d in ranked[:k] if d in r]) / k if k else 0.0


def hit_rate_at_k(ranked, rel, k):
    r = _relevant(rel)
    return 1.0 if any(d in r for d in ranked[:k]) else 0.0


def mrr_at_k(ranked, rel, k):
    r = _relevant(rel)
    for i, d in enumerate(ranked[:k], 1):
        if d in r:
            return 1.0 / i
    return 0.0


def average_precision_at_k(ranked, rel, k):
    r = _relevant(rel)
    if not r:
        return 0.0
    hits, total = 0, 0.0
    for i, d in enumerate(ranked[:k], 1):
        if d in r:
            hits += 1
            total += hits / i
    return total / min(len(r), k)


def _dcg(gains):
    return sum(g / math.log2(i + 2) for i, g in enumerate(gains))


def ndcg_at_k(ranked, rel, k):
    ideal = _dcg(sorted(rel.values(), reverse=True)[:k])
    if ideal == 0:
        return 0.0
    return _dcg([rel.get(d, 0) for d in ranked[:k]]) / ideal


def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a | b) else 0.0


def all_metrics(ranked, rel, k):
    return {
        f"recall@{k}": recall_at_k(ranked, rel, k),
        f"precision@{k}": precision_at_k(ranked, rel, k),
        f"hit@{k}": hit_rate_at_k(ranked, rel, k),
        "mrr": mrr_at_k(ranked, rel, k),
        f"map@{k}": average_precision_at_k(ranked, rel, k),
        f"ndcg@{k}": ndcg_at_k(ranked, rel, k),
    }
