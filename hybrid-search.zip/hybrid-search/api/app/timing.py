import time
from contextlib import contextmanager


class Timings:
    """Accumulates per-stage wall-clock timings in milliseconds."""

    def __init__(self) -> None:
        self.ms: dict[str, float] = {}

    @contextmanager
    def measure(self, name: str):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.ms[name] = self.ms.get(name, 0.0) + (time.perf_counter() - start) * 1000

    def as_dict(self) -> dict[str, float]:
        return {k: round(v, 2) for k, v in self.ms.items()}
