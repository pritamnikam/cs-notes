from pgvector.psycopg import register_vector_async
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool

from .config import settings


async def _configure(conn) -> None:
    await register_vector_async(conn)
    # HNSW returns at most ef_search rows; keep it above the candidate limit.
    await conn.execute("SET hnsw.ef_search = 200")
    await conn.commit()


pool = AsyncConnectionPool(
    settings.database_url,
    min_size=1,
    max_size=10,
    open=False,
    configure=_configure,
    kwargs={"row_factory": dict_row},
)
