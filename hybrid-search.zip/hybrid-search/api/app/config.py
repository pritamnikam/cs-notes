from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql://postgres:postgres@localhost:5432/hybrid"
    ollama_url: str = "http://localhost:11434"
    ollama_timeout: float = 300.0

    embed_model: str = "nomic-embed-text"
    embed_dim: int = 768  # must match vector(N) in db/init.sql
    default_llm: str = "llama3.2"
    reranker_model: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"

    chunk_size: int = 220      # words (~300 tokens)
    chunk_overlap: int = 40    # words
    embed_batch_size: int = 32
    data_dir: str = "/data"

    # Heuristic confidence calibration (tune with your eval set)
    sem_floor: float = 0.35    # cosine at/below which semantic relevance = 0
    sem_ceiling: float = 0.80  # cosine at/above which semantic relevance = 1
    kw_ceiling: float = 0.10   # ts_rank_cd (normalised) at/above which keyword relevance = 1


settings = Settings()
