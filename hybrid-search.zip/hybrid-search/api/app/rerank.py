import asyncio
import json
import math

from .ollama_client import ollama

_cross_encoders: dict = {}


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, x))))


def _cross_encoder_predict(model_name: str, query: str, texts: list[str]) -> list[float]:
    from sentence_transformers import CrossEncoder  # heavy import, lazy

    if model_name not in _cross_encoders:
        _cross_encoders[model_name] = CrossEncoder(model_name)
    raw = _cross_encoders[model_name].predict([(query, t) for t in texts])
    return [_sigmoid(float(s)) for s in raw]


async def _llm_scores(model: str, query: str, texts: list[str]) -> list[float]:
    passages = "\n".join(f"[{i}] {' '.join(t[:800].split())}" for i, t in enumerate(texts))
    system = ("You are a search relevance judge. Score each passage for how well it answers the query "
              "from 0 (irrelevant) to 10 (directly answers). "
              'Reply ONLY with JSON: {"scores": [{"id": 0, "score": 7}, ...]} covering every passage.')
    raw = await ollama.chat(model, [{"role": "system", "content": system},
                                    {"role": "user", "content": f"Query: {query}\n\nPassages:\n{passages}"}],
                            json_mode=True)
    data = json.loads(raw)
    scores = [0.0] * len(texts)
    seen = 0
    for item in data.get("scores", []):
        i = int(item["id"])
        if 0 <= i < len(texts):
            scores[i] = max(0.0, min(1.0, float(item["score"]) / 10.0))
            seen += 1
    if seen == 0:
        raise ValueError("LLM returned no usable scores")
    return scores


async def rerank_scores(kind: str, query: str, texts: list[str], reranker_model: str, llm_model: str) -> list[float]:
    if kind == "cross_encoder":
        return await asyncio.to_thread(_cross_encoder_predict, reranker_model, query, texts)
    if kind == "llm":
        return await _llm_scores(llm_model, query, texts)
    raise ValueError(f"unknown reranker: {kind}")
