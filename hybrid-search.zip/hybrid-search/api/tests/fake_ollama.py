"""Tiny offline stand-in for Ollama (hashing-trick embeddings). For tests / demos without a GPU.
Run: uvicorn tests.fake_ollama:app --port 11434"""
import hashlib
import json
import math
import re

from fastapi import FastAPI

app = FastAPI()
DIM = 768


def _embed(text: str) -> list[float]:
    vec = [0.0] * DIM
    for tok in re.findall(r"[a-z0-9]+", text.lower().replace("search_query:", "").replace("search_document:", "")):
        h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
        vec[h % DIM] += 1.0
    n = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / n for v in vec]


@app.post("/api/embed")
def embed(body: dict):
    return {"embeddings": [_embed(t) for t in body["input"]]}


@app.get("/api/tags")
def tags():
    return {"models": [{"name": "nomic-embed-text:latest"}, {"name": "llama3.2:latest"}]}


@app.post("/api/chat")
def chat(body: dict):
    user = body["messages"][-1]["content"]
    if body.get("format") == "json":  # reranker: score by word overlap
        q = set(re.findall(r"[a-z0-9]+", user.split("Passages:")[0].lower()))
        scores = []
        for m in re.finditer(r"\[(\d+)\] (.*)", user.split("Passages:")[1]):
            words = set(re.findall(r"[a-z0-9]+", m.group(2).lower()))
            scores.append({"id": int(m.group(1)), "score": min(10, 2 * len(q & words))})
        return {"message": {"content": json.dumps({"scores": scores})}}
    return {"message": {"content": "Fake answer based on context [1]."}}
