import math

from app import metrics
from app.chunking import chunk_text


def test_chunking_overlap_and_offsets():
    text = " ".join(f"w{i}" for i in range(100))
    chunks = chunk_text(text, size=30, overlap=10)
    assert len(chunks) == 5  # windows start at 0, 20, 40, 60, 80
    for s, e, t in chunks:
        assert text[s:e] == t
    assert chunks[0][2].split()[-10:] == chunks[1][2].split()[:10]


def test_chunking_short_text_single_chunk():
    assert len(chunk_text("just a few words", 220, 40)) == 1
    assert chunk_text("   ", 10, 2) == []


def test_metrics():
    rel = {"a": 3, "b": 1}
    ranked = ["x", "a", "y", "b"]
    assert metrics.hit_rate_at_k(ranked, rel, 1) == 0.0
    assert metrics.mrr_at_k(ranked, rel, 5) == 0.5
    assert metrics.recall_at_k(ranked, rel, 2) == 0.5
    assert metrics.precision_at_k(ranked, rel, 4) == 0.5
    ideal = metrics.ndcg_at_k(["a", "b"], rel, 5)
    assert math.isclose(ideal, 1.0)
    assert 0 < metrics.ndcg_at_k(ranked, rel, 4) < 1
    assert math.isclose(metrics.jaccard(["a", "b"], ["b", "c"]), 1 / 3)
