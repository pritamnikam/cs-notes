# Hybrid Search Lab

Keyword (Postgres full-text) + semantic (pgvector) + reranking, fused into one ranked result list,
with scores, ranks, confidence, citations and per-stage timings. FastAPI backend, Streamlit UI,
Ollama for embeddings and language models.

```
Streamlit UI (:8501) ──► FastAPI (:8000) ──► PostgreSQL + pgvector (:5432)   ◄── pgAdmin (:5050)
                              └──────────► Ollama (:11434, your Docker Desktop container)
```

## Quick start

1. Make sure Ollama is running with its port published, and pull models:
   ```bash
   docker exec -it <ollama-container> ollama pull nomic-embed-text
   docker exec -it <ollama-container> ollama pull llama3.2
   ```
2. Start everything:
   ```bash
   docker compose up --build            # add WITH_RERANKER=0 to skip the ~2 GB cross-encoder deps
   ```
3. Open **http://localhost:8501** → *Ingest* tab → folder `sample` → *Ingest folder*, then *Search*.
   Open the *Evaluate* tab to compare keyword vs semantic vs hybrid on the bundled labelled queries.

| Service  | URL                              | Notes                                        |
|----------|----------------------------------|----------------------------------------------|
| UI       | http://localhost:8501            |                                              |
| API docs | http://localhost:8000/docs       | OpenAPI / try-it-out                         |
| pgAdmin  | http://localhost:5050            | admin@example.com / admin → add server `db`, user/pass `postgres`, db `hybrid` |

If Ollama runs in a compose network instead of the host, set `OLLAMA_URL` in `.env` (default
`http://host.docker.internal:11434`).

## How search works

| Stage | Implementation |
|-------|----------------|
| Keyword | `tsvector` generated column + GIN index, `websearch_to_tsquery` (AND). If nothing matches, retries with OR semantics. Scored by `ts_rank_cd` (cover density, normalised to 0-1). |
| Semantic | Query embedded by Ollama (`/api/embed`), pgvector HNSW index, cosine similarity. Only chunks from the same embedding model are searched. |
| Fusion | **RRF** (`Σ 1/(60+rank)`, default, score-free) or **weighted** (min-max normalised scores, `α·semantic + (1-α)·keyword`). |
| Rerank | `cross_encoder` (sentence-transformers, sigmoid-scaled) or `llm` (Ollama model scores passages 0-10 as JSON) over the top N fused candidates. Failure degrades to un-reranked results plus a warning. |
| Answer (optional) | LLM answers from the top-K passages with `[n]` citations that map to the `citation` objects. |

### Response shape (`POST /search`)

```jsonc
{
  "search_id": 12, "mode": "hybrid", "search_confidence": 0.88,
  "results": [{
    "rank": 1, "chunk_id": 3, "text": "...", "score": 0.0328,
    "scores": {"keyword": 0.05, "semantic": 0.61, "fused": 0.0328, "rerank": null},
    "ranks":  {"keyword": 1, "semantic": 1, "fused": 1, "final": 1},
    "confidence": 0.92,
    "citation": {"label": "[1]", "document_id": "...", "title": "...", "source": "x.pdf",
                 "chunk_index": 0, "page": 4, "char_span": [0, 612]},
    "metadata": {"found_by": ["keyword", "semantic"]}
  }],
  "answer": null,
  "timings_ms": {"query_embedding": 3.3, "keyword_search": 3.5, "semantic_search": 3.1,
                 "fusion": 0.02, "rerank": 0, "generation": 0, "total": 7.5},
  "models": {"embedding": "nomic-embed-text", "reranker": null, "llm": null},
  "counts": {"keyword_candidates": 4, "semantic_candidates": 7, "merged_candidates": 9, "returned": 5},
  "params": {"fusion": "rrf", "rrf_k": 60, "keyword_query_mode": "and", "reranked": false},
  "warnings": []
}
```

Ingest timings (embedding ms, chunks, documents, skipped, errors) are on `GET /ingest/runs/{id}`.
Every search is logged to `search_logs` (query, params, timings, confidence, result chunk ids).

### Confidence (heuristic: calibrate it)

Per result: `relevance` is the rerank score if present, else the better of keyword and semantic
scores rescaled to 0-1 with `SEM_FLOOR/SEM_CEILING/KW_CEILING` (`config.py`). In hybrid mode
`confidence = 0.75·relevance + 0.25·agreement` (1.0 if both retrievers found it, else 0.5).
Search-level: `0.7·top1 + 0.15·margin(top1-top2) + 0.15·retriever-overlap`.
These constants depend on your embedding model and corpus: fit them against labelled queries
(see `docs/EVALUATION.md`) before using the number to gate answers.

## API summary

`GET /health` · `GET /models` · `POST /ingest` (multipart) · `POST /ingest/folder` ·
`GET /ingest/runs[/{id}]` · `GET /documents` · `DELETE /documents/{id}` · `POST /search` ·
`GET /search/logs` · `POST /eval/run`

## Design notes

- **Idempotent ingestion**: SHA-256 of extracted text; unchanged files are skipped, `force` replaces them.
- **Async ingestion**: `202 + run_id`, background task, progress polled from `ingest_runs`.
- **Embedding provenance**: `chunks.embed_model` stored per row; queries filter on it. Switching models means
  re-ingesting with *force* (or adding a second column/table if you want both side by side).
- **Dimension**: schema uses `vector(768)` (nomic-embed-text). For another model change `vector(N)` in
  `db/init.sql`, `EMBED_DIM` in `.env`, and recreate the volume (`docker compose down -v`).
  Ingest validates the dimension and fails loudly on mismatch.
- **Retrieval cap**: `hnsw.ef_search` is set to 200 per connection so HNSW can return the requested candidates.
- **Safety**: folder ingest is confined to `/data`; request models are validated by Pydantic; SQL is parameterised.
- **Language**: full-text config is `english`; change `to_tsvector('english', ...)` and the query configs for other languages.
- **Chunking**: word-window (default 220 words ≈ 300 tokens, 40 overlap) with char offsets and PDF page numbers.

## Development

```bash
cd api && pip install -r requirements.txt -r requirements-dev.txt && python -m pytest -q   # unit tests
# no GPU / Ollama handy? an offline stand-in is included:
uvicorn tests.fake_ollama:app --port 11434
```

## Extending

Typo tolerance (`pg_trgm`), multilingual FTS configs, metadata filters in the SQL `WHERE`, query rewriting,
MMR diversification, auth on the API, async job queue (Celery/RQ) for very large ingests, `pgvector`
iterative scans for filtered ANN.
